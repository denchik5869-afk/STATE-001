import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  Activity, ArrowDownRight, ArrowUpRight, Building2, CalendarDays,
  ChevronRight, CircleDollarSign, Clock3, Gauge, Landmark, Pause,
  Play, Radio, Shield, Users, WalletCards, X
} from "lucide-react";
import "./styles.css";

type Speed = 1 | 5 | 20;
type EventItem = { id: number; date: string; title: string; text: string; kind: "good" | "bad" | "neutral" };

const initial = {
  date: new Date("2026-01-01T08:00:00"),
  population: 5280000,
  gdp: 42.24,
  inflation: 4.2,
  unemployment: 5.8,
  approval: 52,
  budget: 5.20,
  debt: 18.50
};

const fmt = (n: number, digits = 0) =>
  new Intl.NumberFormat("ru-RU", { maximumFractionDigits: digits, minimumFractionDigits: digits }).format(n);

const money = (n: number) => `${fmt(n, 2)} млрд ₽`;

function App() {
  const [date, setDate] = useState(initial.date);
  const [running, setRunning] = useState(false);
  const [speed, setSpeed] = useState<Speed>(1);
  const [population, setPopulation] = useState(initial.population);
  const [gdp, setGdp] = useState(initial.gdp);
  const [inflation, setInflation] = useState(initial.inflation);
  const [unemployment, setUnemployment] = useState(initial.unemployment);
  const [approval, setApproval] = useState(initial.approval);
  const [budget, setBudget] = useState(initial.budget);
  const [debt, setDebt] = useState(initial.debt);
  const [events, setEvents] = useState<EventItem[]>([
    { id: 1, date: "01.01.2026", title: "Новогоднее обращение", text: "Президент Аурелии обозначил приоритеты нового года.", kind: "neutral" },
    { id: 2, date: "01.01.2026", title: "Бюджет утверждён", text: "Государственный бюджет вступил в силу.", kind: "good" }
  ]);
  const [tab, setTab] = useState("Обзор");

  useEffect(() => {
    if (!running) return;
    const timer = window.setInterval(() => {
      setDate(d => new Date(d.getTime() + speed * 60 * 60 * 1000));
      setPopulation(p => Math.max(0, p + Math.round(p * 0.0000025 * speed)));
      setGdp(g => Math.max(0.1, g * (1 + 0.00004 * speed)));
      setInflation(x => Math.max(0, x + (Math.random() - 0.51) * 0.025 * speed));
      setUnemployment(x => Math.max(0.5, Math.min(25, x + (Math.random() - 0.5) * 0.018 * speed)));
      setApproval(x => Math.max(0, Math.min(100, x + (Math.random() - 0.5) * 0.05 * speed)));
      setBudget(b => b + 0.0015 * speed);
      setDebt(d => Math.max(0, d + (0.0005 - 0.0007) * speed));
    }, 1000);
    return () => window.clearInterval(timer);
  }, [running, speed]);

  useEffect(() => {
    if (!running) return;
    const key = Math.floor(date.getTime() / (6 * 60 * 60 * 1000));
    if (key % 4 === 0 && events[0]?.id !== key) {
      const options: Omit<EventItem, "id" | "date">[] = [
        { title: "Экономический отчёт", text: "Министерство финансов опубликовало очередной оперативный отчёт.", kind: "neutral" },
        { title: "Рост деловой активности", text: "Предприятия сообщают об увеличении внутреннего спроса.", kind: "good" },
        { title: "Социальное напряжение", text: "В отдельных регионах выросло число жалоб граждан.", kind: "bad" }
      ];
      const e = options[Math.abs(key) % options.length];
      setEvents(prev => [{ ...e, id: key, date: date.toLocaleDateString("ru-RU") }, ...prev].slice(0, 12));
    }
  }, [date, running]);

  const dateLabel = date.toLocaleDateString("ru-RU", { day: "2-digit", month: "long", year: "numeric" });
  const timeLabel = date.toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" });
  const gdpPerCapita = (gdp * 1e9) / population;

  const stats = useMemo(() => [
    { label: "Население", value: fmt(population), suffix: "чел.", icon: Users, trend: "+0,01%" },
    { label: "ВВП", value: money(gdp), suffix: "", icon: CircleDollarSign, trend: "+0,04%" },
    { label: "ВВП на душу", value: `${fmt(gdpPerCapita / 1000, 1)} тыс. ₽`, suffix: "", icon: WalletCards, trend: "+0,03%" },
    { label: "Инфляция", value: `${fmt(inflation, 1)}%`, suffix: "", icon: Activity, trend: inflation < 4.2 ? "↓" : "↑", inverse: true },
    { label: "Безработица", value: `${fmt(unemployment, 1)}%`, suffix: "", icon: Gauge, trend: unemployment < 5.8 ? "↓" : "↑", inverse: true },
    { label: "Одобрение", value: `${fmt(approval, 0)}%`, suffix: "", icon: Users, trend: approval >= 52 ? "↑" : "↓" },
    { label: "Бюджет", value: money(budget), suffix: "", icon: Landmark, trend: "+0,02%" },
    { label: "Госдолг", value: money(debt), suffix: "", icon: Building2, trend: debt <= initial.debt ? "↓" : "↑", inverse: true }
  ], [population, gdp, gdpPerCapita, inflation, unemployment, approval, budget, debt]);

  const tabs = ["Обзор", "Экономика", "Правительство", "Общество", "Дипломатия", "Армия"];

  return (
    <div className="app">
      <header className="topbar">
        <div>
          <div className="eyebrow">STATE // 001</div>
          <h1>АУРЕЛИЯ</h1>
          <div className="sub">Президентский центр · Аурис</div>
        </div>
        <div className="status">
          <span className="live-dot" />
          СИМУЛЯЦИЯ
        </div>
      </header>

      <main>
        <section className="hero">
          <div className="date-box">
            <CalendarDays size={18} />
            <div><b>{dateLabel}</b><span>{timeLabel} · Президентский дворец</span></div>
          </div>
          <div className="controls">
            <button className="primary" onClick={() => setRunning(!running)}>
              {running ? <Pause size={17}/> : <Play size={17}/>}
              {running ? "Пауза" : "Запустить"}
            </button>
            {[1, 5, 20].map(s => (
              <button key={s} className={speed === s ? "speed active" : "speed"} onClick={() => setSpeed(s as Speed)}>×{s}</button>
            ))}
          </div>
        </section>

        <nav className="tabs">
          {tabs.map(t => <button key={t} className={tab === t ? "tab active" : "tab"} onClick={() => setTab(t)}>{t}</button>)}
        </nav>

        {tab === "Обзор" && <>
          <section className="section-head">
            <div><span className="kicker">СОСТОЯНИЕ ГОСУДАРСТВА</span><h2>Ключевые показатели</h2></div>
            <span className="refresh"><Radio size={14}/> ОБНОВЛЯЕТСЯ В РЕАЛЬНОМ ВРЕМЕНИ</span>
          </section>

          <section className="grid">
            {stats.map(s => {
              const Icon = s.icon;
              const positive = s.inverse ? s.trend === "↓" : s.trend === "↑";
              return <article className="card" key={s.label}>
                <div className="card-top"><Icon size={18}/><span className={positive ? "trend positive" : "trend"}>{s.trend}</span></div>
                <span className="label">{s.label}</span>
                <strong>{s.value}</strong>
                {s.suffix && <small>{s.suffix}</small>}
              </article>
            })}
          </section>

          <section className="lower">
            <div className="panel">
              <div className="panel-title"><div><span className="kicker">ГОСУДАРСТВЕННАЯ ПОВЕСТКА</span><h2>Последние события</h2></div><ChevronRight size={18}/></div>
              <div className="events">
                {events.slice(0, 6).map(e => <div className="event" key={e.id}>
                  <div className={`event-mark ${e.kind}`} />
                  <div><div className="event-meta">{e.date}</div><b>{e.title}</b><p>{e.text}</p></div>
                </div>)}
              </div>
            </div>
            <div className="panel cabinet">
              <div className="panel-title"><div><span className="kicker">ПРЕЗИДЕНТ</span><h2>Центр управления</h2></div><Shield size={19}/></div>
              <div className="cab-row"><span>Политический капитал</span><b>{fmt(approval, 0)}%</b></div>
              <div className="bar"><i style={{width: `${approval}%`}} /></div>
              <div className="cab-row"><span>Текущая скорость</span><b>×{speed}</b></div>
              <div className="cab-row"><span>Состояние</span><b className={running ? "on" : ""}>{running ? "СИМУЛЯЦИЯ ИДЁТ" : "ПАУЗА"}</b></div>
              <button className="manage" onClick={() => setTab("Экономика")}>Перейти к экономике <ChevronRight size={16}/></button>
            </div>
          </section>
        </>}

        {tab === "Экономика" && <section className="panel full">
          <span className="kicker">МИНИСТЕРСТВО ФИНАНСОВ</span>
          <h2>Экономика</h2>
          <div className="economy-grid">
            {[
              ["ВВП", money(gdp)], ["Инфляция", `${fmt(inflation, 1)}%`],
              ["Безработица", `${fmt(unemployment, 1)}%`], ["Бюджет", money(budget)],
              ["Государственный долг", money(debt)], ["ВВП на душу", `${fmt(gdpPerCapita / 1000, 1)} тыс. ₽`]
            ].map(([a,b]) => <div className="econ-item" key={a}><span>{a}</span><b>{b}</b></div>)}
          </div>
          <div className="notice"><Clock3 size={17}/><span>Экономическая модель v0.1 активна. Следующие версии добавят налоги, расходы, отрасли, торговлю и решения правительства.</span></div>
        </section>}

        {tab !== "Обзор" && tab !== "Экономика" && <section className="panel full placeholder">
          <span className="kicker">МОДУЛЬ ГОСУДАРСТВА</span>
          <h2>{tab}</h2>
          <p>Модуль подготовлен для следующего этапа STATE // 001.</p>
          <div className="planned"><span>✓</span> Структура раздела создана</div>
          <div className="planned"><span>→</span> Механики будут подключены постепенно, без разрушения текущей симуляции</div>
        </section>}
      </main>

      <footer>STATE // 001 <span>·</span> AURELIA SIMULATION <span>·</span> v0.1</footer>
    </div>
  );
}

createRoot(document.getElementById("root")!).render(<App />);
